import { z } from 'zod';

export const registerSchema = z.object({
  email: z.email('Имэйл буруу байна'),
  password: z.string().min(8, 'Нууц үг дор хаяж 8 тэмдэгт'),
  name: z.string().min(1).optional(),
});

export const loginSchema = z.object({
  email: z.email('Имэйл буруу байна'),
  password: z.string().min(1, 'Нууц үг шаардлагатай'),
});

export const refreshSchema = z.object({
  refreshToken: z.string().min(1, 'refreshToken шаардлагатай'),
});
