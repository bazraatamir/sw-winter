import express from 'express';
import { config } from './config/env.js';
import prisma from './lib/prisma.js';
import authRoutes from './routes/auth.js';

const app = express();
app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'auth-service' });
});

app.use('/auth', authRoutes);

// 404
app.use((req, res) => {
  res.status(404).json({ error: 'Олдсонгүй' });
});

// Алдааны төв handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Серверийн алдаа' });
});

const server = app.listen(config.PORT, () => {
  console.log(`🔐 Auth service: http://localhost:${config.PORT}`);
});

// Graceful shutdown
const shutdown = async () => {
  console.log('\nУнтрааж байна...');
  await prisma.$disconnect();
  server.close(() => process.exit(0));
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
