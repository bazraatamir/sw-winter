import 'dotenv/config';
import { z } from 'zod';

// Эхлэхэд л env-ийг шалгана — буруу бол тэр даруй унаж, тодорхой алдаа өгнө
const envSchema = z.object({
  DATABASE_URL: z.string().min(1, 'DATABASE_URL шаардлагатай'),
  JWT_ACCESS_SECRET: z.string().min(16, 'JWT_ACCESS_SECRET дор хаяж 16 тэмдэгт'),
  JWT_REFRESH_SECRET: z.string().min(16, 'JWT_REFRESH_SECRET дор хаяж 16 тэмдэгт'),
  ACCESS_TOKEN_TTL: z.string().default('15m'),
  REFRESH_TOKEN_TTL_DAYS: z.coerce.number().default(7),
  PORT: z.coerce.number().default(4000),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error('❌ Орчны хувьсагч (env) буруу байна:');
  console.error(z.treeifyError(parsed.error));
  process.exit(1);
}

export const config = parsed.data;
