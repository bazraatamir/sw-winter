# Auth Service — Суулгах & Ажиллуулах Заавар

Express дээр суурилсан баталгаажуулалтын (authentication) microservice.
**Stack:** Node.js (ESM) · Express 5 · **Prisma 7.8** (Rust-free) · MariaDB · JWT · bcrypt · zod

---

## Агуулга

1. [Шаардлага](#1-шаардлага)
2. [Суулгах](#2-суулгах)
3. [Тохиргоо (.env)](#3-тохиргоо-env)
4. [Prisma client үүсгэх ба DB бэлдэх](#4-prisma-client-үүсгэх-ба-db-бэлдэх)
5. [Ажиллуулах](#5-ажиллуулах)
6. [API ба урсгал](#6-api-ба-урсгал)
7. [Prisma 7 онцлог тайлбар](#7-prisma-7-онцлог-тайлбар)
8. [Түгээмэл алдаа & засвар](#8-түгээмэл-алдаа--засвар)
9. [PostgreSQL руу шилжих](#9-postgresql-руу-шилжих)
10. [Файлын бүтэц](#10-файлын-бүтэц)

---

## 1. Шаардлага

| Зүйл | Хувилбар |
|------|----------|
| Node.js | 20+ (энэ төсөл 22 дээр шалгасан) |
| MariaDB эсвэл MySQL | 10.5+ / 8.0+ |
| npm | 10+ |

---

## 2. Суулгах

```bash
npm install
```

> Энэ нь `express`, `@prisma/client`, `@prisma/adapter-mariadb`, `bcryptjs`, `jsonwebtoken`, `zod`, `dotenv` болон `prisma` (dev)-г суулгана.

---

## 3. Тохиргоо (.env)

`.env.example`-г хуулна:

```bash
cp .env.example .env
```

Дараа нь **JWT нууц түлхүүрүүдийг** санамсаргүй утгаар үүсгэнэ:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Энэ командыг 2 удаа ажиллуулж, гарсан утгуудыг `.env` доторх `JWT_ACCESS_SECRET` болон `JWT_REFRESH_SECRET`-д тус тус хийнэ. Мөн `DATABASE_URL`-аа MariaDB-дээ тааруулна:

```env
DATABASE_URL="mysql://root:password@localhost:3306/auth_db"
JWT_ACCESS_SECRET="<санамсаргүй 64 тэмдэгт hex>"
JWT_REFRESH_SECRET="<өөр санамсаргүй 64 тэмдэгт hex>"
ACCESS_TOKEN_TTL="15m"
REFRESH_TOKEN_TTL_DAYS=7
PORT=4000
NODE_ENV=development
```

> ⚠️ env буруу бол сервер эхлэхдээ тэр даруй унаж, тодорхой алдаа өгнө (zod-оор шалгадаг).

---

## 4. Prisma client үүсгэх ба DB бэлдэх

### 4.1 Client үүсгэх

```bash
npm run prisma:generate
```

Энэ нь client-ийг **`src/generated/prisma/`** дотор үүсгэнэ.
Prisma 7-д client нь `node_modules` дотор биш, output зам дотор үүсдэг тул `output` талбар **заавал** шаардлагатай (`schema.prisma`-д тохируулсан).

### 4.2 Migration ажиллуулж хүснэгт үүсгэх

MariaDB-д `auth_db` нэртэй сан үүсгэсэн байх ёстой (эсвэл migrate автоматаар оролдоно):

```bash
npm run prisma:migrate
```

Энэ нь `User`, `RefreshToken` хүснэгтийг үүсгэнэ.

---

## 5. Ажиллуулах

```bash
npm run dev      # node --watch — файл өөрчлөгдөхөд автоматаар дахин ачаална
# эсвэл production маягаар:
npm start
```

Шалгах:

```bash
curl http://localhost:4000/health
# {"status":"ok","service":"auth-service"}
```

---

## 6. API ба урсгал

Бүх endpoint `/auth` доор байна.

| Method | Зам | Тайлбар | Хамгаалалт |
|--------|-----|---------|-----------|
| POST | `/auth/register` | Бүртгүүлэх | Нээлттэй |
| POST | `/auth/login` | Нэвтрэх | Нээлттэй |
| POST | `/auth/refresh` | Шинэ access token авах | Нээлттэй (refresh token-оор) |
| POST | `/auth/logout` | Гарах (refresh token цуцлах) | Нээлттэй |
| GET | `/auth/me` | Профайл харах | 🔒 Bearer token |

### Бүрэн урсгал (curl)

**1. Бүртгүүлэх**

```bash
curl -X POST http://localhost:4000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123","name":"Бат"}'
```

Хариу: `{ user, accessToken, refreshToken }`

**2. Нэвтрэх**

```bash
curl -X POST http://localhost:4000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

**3. Хамгаалагдсан route руу хандах**

```bash
curl http://localhost:4000/auth/me \
  -H "Authorization: Bearer <accessToken>"
```

**4. Token шинэчлэх** (access token хугацаа дуусахад)

```bash
curl -X POST http://localhost:4000/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{"refreshToken":"<refreshToken>"}'
```

**5. Гарах**

```bash
curl -X POST http://localhost:4000/auth/logout \
  -H "Content-Type: application/json" \
  -d '{"refreshToken":"<refreshToken>"}'
```

### Аюулгүй байдлын онцлогууд

- Нууц үг **bcrypt** (12 salt round)-аар hash хийгдэнэ
- Refresh token нь DB-д **sha256 hash** хэлбэрээр хадгалагдана (анхны утга биш)
- **Token rotation**: refresh хийх бүрт хуучин refresh token хүчингүй болж шинэ нь өгөгдөнө
- Нэвтрэхэд буруу имэйл/нууц үгэнд ижил алдаа буцаана (account enumeration-аас сэргийлнэ)
- env-д нууц түлхүүр дутуу бол сервер эхлэхгүй

---

## 7. Prisma 7 онцлог тайлбар

Prisma 6-аас 7 рүү гарсан **гол өөрчлөлтүүд** ба энэ төсөлд хэрхэн зассан:

| Өөрчлөлт | Энэ төсөлд |
|----------|-----------|
| `prisma-client-js` → `prisma-client` generator (Rust-free, ESM) | `schema.prisma`-д `provider = "prisma-client"` |
| Client `node_modules`-д биш, `output` зам заавал | `output = "../src/generated/prisma"` |
| `new PrismaClient({ datasourceUrl })` **устсан** | `new PrismaClient({ adapter })` ашигласан |
| Driver adapter **заавал** | `@prisma/adapter-mariadb` |
| Холболтын URL schema-д биш | `prisma.config.ts` дотор `datasource.url` |
| Import нь `@prisma/client`-аас биш | `../generated/prisma/client.js`-аас |

**Client үүсгэх (createClient) хэв маяг** — `src/lib/prisma.js`:

```js
import { PrismaClient } from '../generated/prisma/client.js';
import { PrismaMariaDb } from '@prisma/adapter-mariadb';

const adapter = new PrismaMariaDb(process.env.DATABASE_URL);
const prisma = new PrismaClient({ adapter });  // ⭐ adapter заавал
```

`singleton` хэв маяг нь `node --watch` (hot-reload) үед олон холболт үүсэхээс сэргийлнэ.

---

## 8. Түгээмэл алдаа & засвар

| Алдаа | Шалтгаан | Засвар |
|-------|----------|--------|
| `Cannot find module '../generated/prisma/client.js'` | `prisma generate` ажиллуулаагүй | `npm run prisma:generate` |
| `requires either "adapter" or "accelerateUrl"` | adapter дамжуулаагүй | `new PrismaClient({ adapter })` |
| `datasource property url is no longer supported` | schema-д `url` үлдсэн | `url`-г `prisma.config.ts` руу шилжүүл |
| `ERR_MODULE_NOT_FOUND` (local import) | ESM-д `.js` өргөтгөл дутуу | local import-д `.js` нэм |
| `__dirname is not defined` | ESM-д байхгүй | `fileURLToPath(import.meta.url)` ашигла |
| env алдаа гараад унана | `.env` дутуу/буруу | `.env.example`-тэй тулгаж шалга |

---

## 9. PostgreSQL руу шилжих

Хэрэв MariaDB биш PostgreSQL ашиглах бол зөвхөн 3 өөрчлөлт:

```bash
npm remove @prisma/adapter-mariadb
npm install @prisma/adapter-pg
```

`schema.prisma`:
```prisma
datasource db {
  provider = "postgresql"
}
```

`src/lib/prisma.js`:
```js
import { PrismaPg } from '@prisma/adapter-pg';
const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL });
```

Бусад код хэвээрээ ажиллана.

---

## 10. Файлын бүтэц

```
auth-service/
├── prisma/
│   └── schema.prisma          # User, RefreshToken модель + generator
├── prisma.config.ts           # ⭐ DATABASE_URL энд (Prisma 7)
├── src/
│   ├── index.js               # Express app
│   ├── config/
│   │   └── env.js             # env-ийг zod-оор шалгана
│   ├── lib/
│   │   └── prisma.js          # ⭐ createClient + adapter singleton
│   ├── middleware/
│   │   └── auth.js            # requireAuth, requireRole
│   ├── utils/
│   │   ├── jwt.js             # access/refresh token, hash
│   │   └── password.js        # bcrypt hash/verify
│   ├── validators/
│   │   └── auth.schema.js     # zod schema
│   ├── routes/
│   │   └── auth.js            # register/login/refresh/logout/me
│   └── generated/prisma/      # prisma generate үүсгэнэ (git-д орохгүй)
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── SETUP.md                   # энэ файл
```

---

Асуудал гарвал эхлээд `npm run prisma:generate` ажилласан эсэх, `.env` бүрэн эсэхийг шалгаарай. Ихэнх алдаа эдгээрээс үүсдэг.
