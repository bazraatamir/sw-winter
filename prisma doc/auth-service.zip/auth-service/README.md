# Auth Service

Express + **Prisma 7.8** дээр суурилсан баталгаажуулалтын microservice (ESM, MariaDB, JWT).

## Хурдан эхлэх

```bash
npm install
cp .env.example .env          # JWT secret + DATABASE_URL засна
npm run prisma:generate
npm run prisma:migrate
npm run dev
```

📖 **Дэлгэрэнгүй заавар:** [SETUP.md](./SETUP.md)

## Онцлог

- JWT access + refresh token (token rotation)
- bcrypt нууц үг hash
- zod input + env validation
- Prisma 7 зөв тохиргоо (adapter, prisma.config.ts, output path)
- Role-д суурилсан хандалт (USER / ADMIN)

## Endpoint-ууд

| Method | Зам | Тайлбар |
|--------|-----|---------|
| POST | `/auth/register` | Бүртгүүлэх |
| POST | `/auth/login` | Нэвтрэх |
| POST | `/auth/refresh` | Token шинэчлэх |
| POST | `/auth/logout` | Гарах |
| GET | `/auth/me` | Профайл (🔒) |
